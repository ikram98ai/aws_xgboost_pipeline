import boto3
import pickle
import io 
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import xgboost

s3 = boto3.client('s3')
def lambda_handler(event, context):
   
    try:
        # Get the input data path and pipeline name from the event
        input_data = event['data']
        retail_name = event.get('retail_name',None)

        artifact = model_artifact_from_s3(retail_name)
        model = artifact['model']
        encoders = artifact['encoders']
        score = artifact['score']

        x = prepare_data(input_data,encoders)
        pred =model.predict(x)
        optimal_price = get_optimal_price(model,x)

        return {
            'statusCode': 200, 
            'body': {
                'prediction': pred, 
                'optimal_price':optimal_price, 
                'score': score
                }
            }
    except Exception as e:
        return {
            'statusCode': 500, 
            'body': { 'error': str(e) }
            }

def get_optimal_price(model,x,target_day):
    bounds = (int(x.price) - 50, int(x.price) + 50) # Price bounds

    best_price = None
    min_error = float('inf')
    # Define the objective function (same as in Bayesian optimization)
    for price in range(bounds[0],bounds[1]):
        x['price'] = price
        pred = model.predict(x)[0]
        error = round((pred - target_day),4)
        print('pred:{}, error:{}, price:{} '.format(pred,error,price))
        if error <= min_error:
            min_error = error
            best_price = price
    return best_price


# Download the model file from S3
def model_artifact_from_s3(retail_name):
    BUCKET_NAME = 'turnover-data-123'
    file_key = f'output/{retail_name}_model_artifact.pkl'
 
    # Download the model artifact from S3
    response = s3.get_object(Bucket=BUCKET_NAME, Key=file_key)
    # Load the file's content
    file_content = response['Body'].read()
    # Load the object using pickle
    artifact = pickle.load(io.BytesIO(file_content))
    
    return artifact




def prepare_data(input_data,encoders):
    x = pd.DataFrame(input_data,index=[0])
    print('Preparing data...')

    x['category'] = x['category'].str.strip().str.lower()
    x['brand1'] = x['brand1'].str.strip().str.lower()
    x['brand2'] = x['brand2'].str.strip().str.lower()
    x['brand3'] = x['brand3'].str.strip().str.lower()
    x['description'] = x['description'].str.strip().str.lower()
    x['desc_len'] = x.description.str.len()
    x['cate_len'] = x.category.str.len()
    x['brand1_len'] = x.brand1.str.len()
    x['brand2_len'] = x.brand2.str.len()
    x['brand3_len'] = x.brand3.str.len()

    x['created_day'] = x.item_created_date.dt.day
    x['created_month'] = x.item_created_date.dt.month
    x['created_week_day'] = x.item_created_date.dt.day_of_week
    x['created_quarter']= x.item_created_date.dt.quarter
    x['created_year_day']= x.item_created_date.dt.day_of_year
    x['created_hour'] = x.item_created_date.dt.hour

    x['month_sin'] = np.sin(2 * np.pi * x['created_month'] / 12)
    x['month_cos'] = np.cos(2 * np.pi * x['created_month'] / 12)
    x['day_sin'] = np.sin(2 * np.pi * x['created_day'] / 31)
    x['day_cos'] = np.cos(2 * np.pi * x['created_day'] / 31)
    x['week_day_sin'] = np.sin(2 * np.pi * x['created_week_day'] / 7)
    x['week_day_cos'] = np.cos(2 * np.pi * x['created_week_day'] / 7)
    x['year_day_sin'] = np.sin(2 * np.pi * x['created_year_day'] / 365)
    x['year_day_cos'] = np.cos(2 * np.pi * x['created_year_day'] / 365)
    x['hour_sin'] = np.sin(2 * np.pi * x['created_hour'] / 24)
    x['hour_cos'] = np.cos(2 * np.pi * x['created_hour'] / 24)

    x['brand1'] = label_encoder(encoders['brand1_le'], x.brand1)
    x['brand2'] = label_encoder(encoders['brand2_le'], x.brand2)
    x['brand3'] = label_encoder(encoders['brand3_le'], x.brand3)
    x['category'] = label_encoder(encoders['cate_le'], x.category)

    features = ['item_created_date','description']
    x =x.drop(features,axis=1)

    return x


def label_encoder(encoder:LabelEncoder, data:pd.Series):
    na_label = 'unknown'
    labels = data.map(lambda x: na_label if x not in encoder.classes_ else x)
    if not set(encoder.classes_ ).issuperset(labels):
        encoder.classes_ = np.append(encoder.classes_,na_label)
        print('unknown label apended')
    return encoder.transform(labels).astype(int)
    
