import boto3
import pickle
import pandas as pd
import numpy as np
from io import StringIO
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import r2_score, mean_absolute_error as mae
from xgboost import XGBRegressor
import scipy.stats as st

s3 = boto3.client('s3')
def lambda_handler(event, context):
   
    # Get the input data path and pipeline name from the event
    training_data_path = event.get('input_data_path',None)
    retail_name = event.get('retail_name',None)

    if retail_name and training_data_path :
        try:

            df = get_df_from_s3uri(training_data_path)
            train_df, test_df, encoders = prepare_data(df)
            model_artifact = train_model(train_df, test_df, encoders)
            save_to_s3(model_artifact, retail_name)

            return {
                'statusCode': 200, 'body': {'message': 'Model trained successfully'}
            }
        except Exception as e:
            return {
                'statusCode': 500,  'body': {'error': str(e)}
            }
    else:
        return {
            'statusCode': 400, 'body': {'error': 'Invalid request'}
        }



def get_df_from_s3uri(input_data_path):
    print('Getting data from s3...')
    s3 = boto3.client('s3')
    bucket_name, key_name = input_data_path.replace("s3://", "").split("/", 1)

    # Download CSV file from S3
    response = s3.get_object(Bucket=bucket_name, Key=key_name)
    
    # Read CSV content into Pandas DataFrame
    csv_content = response['Body'].read().decode('utf-8')
    df = pd.read_csv(StringIO(csv_content),parse_dates=['item_sold_date','item_created_date'])
 
    return df


def prepare_data(df):
    print('Preparing data...')

    if 'Is internal' in df.columns:
        print(f"Removing {len(df[df['Is internal']==1])} internally transfered items")
        df = df[df['Is internal']!=1].reset_index(drop=True)

    features = ['item_sold_date','item_created_date','price','description', 'CategoryFromDescription', 'Brand1','Brand2','Brand3']
    df = df[features]

    df = df.rename({'CategoryFromDescription':'category', 'Brand1':'brand1','Brand2':'brand2','Brand3':'brand3'},axis=1)

   
    print("Before:",df.shape)
    df = df.drop_duplicates()
    df = df.dropna()
    df = df.reset_index(drop=True)
    print("After:",df.shape)


    df['category'] = df['category'].fillna('unknown').str.strip().str.lower()
    df['brand1'] = df['brand1'].str.strip().str.lower()
    df['brand2'] = df['brand2'].str.strip().str.lower()
    df['brand3'] = df['brand3'].str.strip().str.lower()
    df['description'] = df['description'].str.strip().str.lower()
    df['desc_len'] = df.description.str.len()
    df['cate_len'] = df.category.str.len()
    df['brand1_len'] = df.brand1.str.len()
    df['brand2_len'] = df.brand2.str.len()
    df['brand3_len'] = df.brand3.str.len()

    df['created_day'] = df.item_created_date.dt.day
    df['created_month'] = df.item_created_date.dt.month
    df['created_week_day'] = df.item_created_date.dt.day_of_week
    df['created_quarter']= df.item_created_date.dt.quarter
    df['created_year_day']= df.item_created_date.dt.day_of_year
    df['created_hour'] = df.item_created_date.dt.hour

    df['month_sin'] = np.sin(2 * np.pi * df['created_month'] / 12)
    df['month_cos'] = np.cos(2 * np.pi * df['created_month'] / 12)
    df['day_sin'] = np.sin(2 * np.pi * df['created_day'] / 31)
    df['day_cos'] = np.cos(2 * np.pi * df['created_day'] / 31)
    df['week_day_sin'] = np.sin(2 * np.pi * df['created_week_day'] / 7)
    df['week_day_cos'] = np.cos(2 * np.pi * df['created_week_day'] / 7)
    df['year_day_sin'] = np.sin(2 * np.pi * df['created_year_day'] / 365)
    df['year_day_cos'] = np.cos(2 * np.pi * df['created_year_day'] / 365)
    df['hour_sin'] = np.sin(2 * np.pi * df['created_hour'] / 24)
    df['hour_cos'] = np.cos(2 * np.pi * df['created_hour'] / 24)

    df['target'] = (df['item_sold_date'] - df['item_created_date']).dt.days

    print("Before:",df.shape)
    df['turnover_zscore'] = st.zscore(df.target,nan_policy='omit')
    df = df[(df['turnover_zscore'] <3) & (df['turnover_zscore'] >-3)].drop('turnover_zscore',axis=1).reset_index(drop=True)
    print("After:",df.shape)

    print("Before:",df.shape)
    df['price_zscore'] = st.zscore(df.price)
    df = df[(df['price_zscore'] <3) & (df['price_zscore'] >-3)].drop('price_zscore',axis=1).reset_index(drop=True)
    print("After:",df.shape)

    features = ['item_sold_date', 'item_created_date','description']
    df0 =df.drop(features,axis=1)
    print(df0.shape)
    df0.sample(2)

    train_df, test_df = train_test_split(df0.sample(df0.shape[0]),test_size=.2,random_state=42)

    brand1_le = LabelEncoder().fit(train_df.brand1)
    brand2_le = LabelEncoder().fit(train_df.brand2)
    brand3_le = LabelEncoder().fit(train_df.brand3)
    cate_le = LabelEncoder().fit(train_df.category)

    encoders = {
        'brand1_le': brand1_le,
        'brand2_le': brand2_le,
        'brand3_le': brand3_le,
        'cate_le': cate_le
    }
    
    return train_df, test_df, encoders


def label_encoder(encoder:LabelEncoder, data:pd.Series,training=True):
    if training:     return encoder.transform(data).astype(int)
    
    na_label = 'unknown'
    labels = data.map(lambda x: na_label if x not in encoder.classes_ else x)
    if not set(encoder.classes_ ).issuperset(labels):
        encoder.classes_ = np.append(encoder.classes_,na_label)
        print('unknown label apended')
    return encoder.transform(labels).astype(int)
    

def train_model(train_df, test_df, encoders):
    print('encoding data...')
    train_df['brand1'] = label_encoder(encoders['brand1_le'], train_df.brand1)
    train_df['brand2'] = label_encoder(encoders['brand2_le'], train_df.brand2)
    train_df['brand3'] = label_encoder(encoders['brand3_le'], train_df.brand3)
    train_df['category'] = label_encoder(encoders['cate_le'], train_df.category)

    test_df['brand1'] = label_encoder(encoders['brand1_le'], test_df.brand1,training=False)
    test_df['brand2'] = label_encoder(encoders['brand2_le'], test_df.brand2,training=False)
    test_df['brand3'] = label_encoder(encoders['brand3_le'], test_df.brand3,training=False)
    test_df['category'] = label_encoder(encoders['cate_le'], test_df.category,training=False)

    x_train = train_df.drop('target',axis=1)
    y_train = train_df['target'] 
    x_test = test_df.drop('target',axis=1)
    y_test = test_df['target'] 

    print('training model...')
 
    params = {
        'colsample_bytree': 0.010149089357646943,
        'learning_rate': 0.18929299937904528,
        'max_depth': 12,
        'min_child_weight': 0.08398519264651351,
        'n_estimators': 130,
        'reg_alpha': 0.0019124216150545785,
        'reg_lambda': 0.22273904444456094,
        'subsample': 0.15786819101229257
        }
    model = XGBRegressor(objective='reg:squarederror',random_state=42,**params).fit(x_train, y_train)

    y_pred = model.predict(x_test)
    
    score = {
            'r2':round(r2_score(y_test, y_pred),4),
            'mae':round(mae(y_test, y_pred), 4)
        }  
     
    model_artifact = {
        'model': model,
        'encoders': encoders,
        'score': score
    }
    print('Model aritfact saved successfully.')

    return model_artifact
    

def save_to_s3(model_artifact, retail_name):
    BUCKET_NAME = 'turnover-data-123'
    file_key = f'output/{retail_name}_model_artifact.pkl'
    try:
        serialized_data = pickle.dumps(model_artifact)
        s3.put_object(Bucket=BUCKET_NAME, Key=file_key, Body=serialized_data)
        print(f'File {file_key} uploaded successfully to {BUCKET_NAME}')
        
    except Exception as e:
        print(f"Error uploading to S3: {e}")
        raise Exception(str(e))
    